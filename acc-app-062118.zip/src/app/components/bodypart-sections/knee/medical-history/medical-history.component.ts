import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { FormsModule, ReactiveFormsModule} from '@angular/forms';

@Component({
  selector: 'app-medical-history',
  templateUrl: './medical-history.component.html',
  styleUrls: ['./medical-history.component.scss']
})
export class MedicalHistoryComponent implements OnInit {

  toggleSection: boolean = true;
  medHistoryForm: FormGroup;

  constructor( private _formBuilder: FormBuilder) { 
    this.createForm();
  }

  ngOnInit() {
  }

  createForm(){
    this.medHistoryForm = this._formBuilder.group({
      finalDiagnosis: '',
      diagnosis: '',
      servicePeriod: '',
      dateOfOnsetRight: '', dateOfOnsetLeft: '',
      detailsOfOnsetRight: '', detailsOfOnsetLeft: '',
      currentSympRight: '', currentSympLeft: '',
      sympProgressRight: '', sympProgressLeft: '',
      medications: '',
      priorTreatments: '',
      flareUpsImpactSelect: '', flareUpsImpact: '', 
      lossImparementSelect: '', lossImparement: '', 
      flareUpLimitSelect: '', flareUpLimit: '', 
      repUseLimitSelect: '', repUseLimit: '', 
      evidenceComments: '',
    });
  };

  hideShowSection(){
    this.toggleSection = !this.toggleSection;
  }

}
