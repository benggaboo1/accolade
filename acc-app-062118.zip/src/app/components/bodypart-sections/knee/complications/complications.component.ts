import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { FormsModule, ReactiveFormsModule} from '@angular/forms';

@Component({
  selector: 'app-complications',
  templateUrl: './complications.component.html',
  styleUrls: ['./complications.component.scss']
})
export class ComplicationsComponent implements OnInit {

  toggleSection: boolean = true;
  disabilitiesForm: FormGroup;

  constructor( private _formBuilder: FormBuilder) { 
    this.createForm();
  }

  ngOnInit() {
  }

  createForm(){
    this.disabilitiesForm = this._formBuilder.group({
      finalDiagnosis: '',
      diagnosis: ''
    });
  };

  hideShowSection(){
    this.toggleSection = !this.toggleSection;
  }

}
