import { Component, OnInit } from '@angular/core';
import { AccFormsComponent } from '../../components/accForms/accForms.component';
import { ReportsComponent } from '../../components/reports/reports.component';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
