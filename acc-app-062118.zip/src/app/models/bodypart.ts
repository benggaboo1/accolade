export class BodyPart {
    id: number  = 0;
    code: string;
    routerlink: string;
    label: string;
}

